import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <h2 style="color:red">Some Heading</h2>
  <h2 [style.color]="'orange'">Some Other Heading</h2>

  <h2 [style.color]="hasError ? 'red': 'green'">Some Heading Again</h2>

  <h2 [ngStyle]="titleStyle">Some Important Heading</h2>

  `,
  styles: [`
  
  
  `]
})
export class TestComponent implements OnInit {

  public hasError = false;

  public titleStyle = {
    color: 'blue',
    fontSize: '92px',
    fontStyle: 'italic' 
  }

  constructor() { }

  ngOnInit() {
  }

  



}
