import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  
  <button (dblclick)="onButtonClick($event)" >Button</button>

  <h2 (click)="onButtonClick($event)">Some Heading</h2>

  <div (click)="onButtonClick($event)" style="padding:20px; height: 50px; width: 50px; border: 1px solid red">Hello</div>


  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
 
  
  constructor() { }

  ngOnInit() {
  }

  onButtonClick(event){
    console.log(event.type);
  }




}
