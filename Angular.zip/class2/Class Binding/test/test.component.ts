import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <h1 class="text-danger2">Some Heading<h1>
  <h1 [class]="textSuccess" >Some Other Heading</h1>
<h1 [class.text-special]="isSpecial" >Some Heading Again</h1>

  <h1 [class.text-danger]="hasError">Some More Heading</h1>

  <h1 [ngClass]="message">Some Important Heading</h1>


  `,
  styles: [`
  
  .text-success{
    color: green
  }

  .text-danger3{
    color: red
  }

  .text-special{
    font-style: italic
  }
  
  `]
})
export class TestComponent implements OnInit {

public hasError = true;
public isSpecial = true;

public message = {
  "text-success": !this.hasError,
  "text-danger": this.hasError,
  "text-special": this.isSpecial
}



  public textSuccess = "text-danger3";
  
  constructor() { }

  ngOnInit() {
  }

  



}
