# Angular

# Component

- A resuable UI segment visible to the end user
- Used to specify HTML element and logic for user interaction

# Component
4 files
- component.ts - component typescript class where we write component logic 
- component.css - is use to style your component
- component.html - as a template where we write the html
- component.spec.ts - is use for unit testing


# Component
template    +   Class    		+ MetaData   =  Component
view/		Typescript		Decorator
HTML		Data and Methods	Information


# Decorator
- A fucntion that add meta data to a class
- these are prefix with @ symbol
- Angular has built in decorator like @Component for defining Component


# Type of decorators
@Component - use for definig component
@NgModule - use for defining module
@Pipe - use for defining pipe
@Injector - use for defining services


# Metadata
- tells angular how to process a class
- tempate, metadata and component together specify the view


@Component main properties
- selector - use to define html tag for your component
- templateUrl - to link external html file for component
- StylesUrl - to link external css file for component
- template - to write html in line
- styles - to write css in line
- providers - to register service



# Nesting of component
we can include multiple component in each other to compose our web page


# How to install bootstrap in angular
1. add bootstrap css CDN link directly in index.html
2. install bootstrap using npm
	> npm install bootstrap --save
	> In angular.json add bootstrap.css file
	> restart the server



# Data binding

One way data binding - where data will flow from component class to template
One way data binding - where data will flow from template to component class
Two way data binding - where data flow from template to component class and from 
			component class to template


- Interpollation
- Property binding

when you want to send data from component class to template
- Interpolation
- Property binding


# Interpolation - Data binding
we can use interpolation for data binding or sending data from component class to template

we can use interpolation for executing any expression

syntex - {{  }}
in the interpolation we can also use all javascript functions and properties

and we can also use interpolation with our own custom methods


# Property Binding
when we want to send data from component class to template

syntex
------
[] enclose the property name with a pair of square bracket whichu wish to bind



Interpolation VS Property Binding
> Interpolation is a special syntex that angular convert into property binding
> To concatanete string we must use interpolation instead of property binding
> To set an element property to a non string data value you must use property
binding


# Event Binding
When data flow from template to component class
Event binding data flow in the opposite direction ie from HTML
to component class


syntex
------
(click) - binding of click event

#event = this is reserve keyword in angular which contain the entire information
of the current event




# CLass Binding
class binding is use to dynamically apply any css class on any html element
use [] for class binding

[ngClass] - special directive provided by angular when you want to apply multiple 
css class conditionally

# Style Binding
style binding us use when we want to apply any style dynamically
[ngStyle] - special directive to apply multiple styles
























