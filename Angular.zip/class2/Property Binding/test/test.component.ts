import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  
  <img [src]="imagePath"/>
  <img src="{{ imagePath }}"/>
  <br><br>

  <button >Button</button>
  <button disabled="isDisabled">Button</button>
  <button [disabled]="isDisabled" >Button</button>

  <br><br>
  <img src="{{ imagePath + imageName }}"/>
  


  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
 
  public imagePath = "https://www.iiht.com/wp-content/uploads/2018/11/";
  public imageName = "iiht-logo1.png";

  public name = "Mark Smith";
  public isDisabled = false;

  constructor() { }

  ngOnInit() {
  }




}
