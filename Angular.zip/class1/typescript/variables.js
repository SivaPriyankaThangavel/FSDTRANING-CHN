var a;
var b;
function test() {
    for (var i = 0; i < 5; i++) {
        console.log(i);
    }
    console.log("Outside: " + i);
}
test();
