var Dimension = /** @class */ (function () {
    function Dimension(x, y) {
        this.x = x;
        this.y = y;
    }
    Dimension.prototype.draw = function () {
        console.log("X: " + this.x + ", Y: " + this.y);
    };
    Dimension.prototype.getArea = function () {
        // fucntion body
    };
    return Dimension;
}());
var dim = new Dimension(10, 20);
//dim.x = -10;
//dim.y = 20;
dim.draw();
