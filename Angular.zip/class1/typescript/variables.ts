let a;
var b;


function test(){
    for(let i=0;i<5;i++){
        console.log(i);
    }

    console.log("Outside: "+ i);

}

test();