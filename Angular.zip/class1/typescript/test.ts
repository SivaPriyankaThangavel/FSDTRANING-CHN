class Student{

    private id: number;
    private name: string;
    private passMark: number = 40;

    constructor(id:number, name?: string){
        this.setId(id);
        this.setName(name);
    }

    addNumber(num1? = 10, num2?){
        console.log(`Sum: ${num1 + num2} `);

    }

    getId(){
        return this.id;
    }

    setId(id: number){
        if(id>0){
            this.id = id;
        }else{
            console.log("Id is invalid");
        }
    }

    getName(){
        return this.name;
    }

    setName(name: string){
        if(name!=null){
            this.name = name;
        }else{
            console.log("name cannot be null");
        }
    }

    getPassMark(){
        return this.passMark;
    }




    display(){
        console.log(`Student: Id-${this.id}, Name-${this.name}, PassMark-${this.passMark}`);
    }

}

let obj = new Student(10, "");

obj.addNumber();

obj.setId(-1);
obj.setName(null);


obj.display();


