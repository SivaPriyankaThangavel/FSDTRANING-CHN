var Student = /** @class */ (function () {
    function Student() {
        this.passMark = 40;
    }
    Student.prototype.getId = function () {
        return this.id;
    };
    Student.prototype.setId = function (id) {
        if (id > 0) {
            this.id = id;
        }
        else {
            console.log("Id is invalid");
        }
    };
    Student.prototype.getName = function () {
        return this.name;
    };
    Student.prototype.setName = function (name) {
        if (name != null) {
            this.name = name;
        }
        else {
            console.log("name cannot be null");
        }
    };
    Student.prototype.getPassMark = function () {
        return this.passMark;
    };
    Student.prototype.display = function () {
        console.log("Student: Id-" + this.id + ", Name-" + this.name + ", PassMark-" + this.passMark);
    };
    return Student;
}());
var obj = new Student();
obj.setId(-1);
obj.setName(null);
obj.display();
