

export class Shape{}

export class Circle{}

export class Rectangle {}


export class Dimension2{
    //private x: number;
    //private y: number;

    constructor(private _x?: number,private  _y?:number){
        
    }


    get X(){
        return this._x;
    }

    set X(value){
        this._y = value;
    }






    // setX(value: number){
    //     if(value >0 ){
    //         this.x = value;
    //     }
    //     else{

    //     }
    // }




    // getX(): number{
    //     return this.x;
    // }




}


// let dim = new Dimension(10, 20);

// console.log(dim.X);

// dim.X = 10;




//dim.x = -10;
//dim.y = 20;

// dim.draw();

