let a : number;
let b: boolean;
let c: string;
let d: any;
let e:number[] = [1,2,3];
let f:any[] = [1, "Hello", true];


const red = 0;
const yellow = 1;

enum Color {Red=1, Green=2, Yellow=3}
let selectedColor = Color.Green;