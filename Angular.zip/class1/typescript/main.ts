function log(message){
    console.log(message);
}

var message = "Hello World";

log(message);