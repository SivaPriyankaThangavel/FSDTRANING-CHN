var a;
var b;
var c;
var d;
var e = [1, 2, 3];
var f = [1, "Hello", true];
var red = 0;
var yellow = 1;
var Color;
(function (Color) {
    Color[Color["Red"] = 1] = "Red";
    Color[Color["Green"] = 2] = "Green";
    Color[Color["Yellow"] = 3] = "Yellow";
})(Color || (Color = {}));
var selectedColor = Color.Green;
