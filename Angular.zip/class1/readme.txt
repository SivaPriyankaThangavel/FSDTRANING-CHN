# TypeScript
Typescript is wor as a wrapper on top of javascript with the help of typescript
we can write javascript code the way we really like it

Typescript is a typed superset of javascript that compile tp plain javascript

TypeScript is pure object oriented with classes, interface and statically types like
C# and Java

Typescript was develop by Microsoft

# Features of Typescript
1. You can use typescript to write OOP
2. The code finally compile or transpile into plain javascript 



# Typescript
- strongly typing
- Object Oreinted features
- Compile time error
- Great editor support


Typescript --------> transpiler------------> Javascript

install VSCode
install node

node --version
npm --version

npm install typescript -g

create a main.ts
> tsc main.ts  -> generate main.js
> node main  -> to execute and see the output



Typescript
> variable
> Datatypes
> function
> interface
> class
> objects
> constructor
> how to make constructor parameters optional (?)
> getter and setters
> exporting and importing classes



# Angular

- One framework for building and web and mobile application
- Written in typescript
- Simple and expressive
- web component base architecture
- Inbuild capability for dependecy injection
- Not an update to AngularJs or Angular 1.x



AngularJS or 1.x
Angular 2/4/5/6/7/8


Angular 2 and above Vs AngularJS or 1.x

Angular 2 and above
- bootstrap fucntion is used to initialize
- Support pipes
- support camelcase sytex ngModel, ngClass
- uses HTML DOM element properties ansd events
- uses () for event and [] for property binding
- not available

Angular 1 or AnglarJS
- ng-app is used to initialize
- support filters
- support sinal case like ng-model, ng-class
- uses it own directives like ng-click, ng-show
- does not support () and [] syntex for binding
- scope, controller, service. factory


# Building blocks of Angular
- Modules
- Components
- Templates
- Decorators
- Services
- Pipes
- Routing
- Forms


# Angular CLI (command line interface)
A powerfull tool to create, build, compile and serve angular application
It is use to generate new project, new modeuls, new component in angular application




# Initial Setup
- Text Editor - VSCode
- NOdeJS and npm
- Angular/cli using npm


# Create your first Angular project
ng new <project name>
cd <project name>
ng serve  ||   ng s   || ng s -o


default port for angular application is 4200


localhost:4200/



# Angular project structure

package.json - conatins the list of dependencies or packages to build and run
	       angular application

node_modules - packages specified in the package.json file are installed
                into this folder

e2e - contain end to end testing and their configuration file

editorconfig - configuartion file for visual studio code

.gitignore - file and folder listed in this file and ou want to ignore
             when you upload your code into source code repo

angular.json - configuartion file for your entire angular app

Readme.MD  -  file contain the commonly use angular cli command or
             any other instruction for developer team

tsconfig.json - typescript compiler confuration file

src - contain the angular project source code

app - where you create all components, module and other angular stuff

assets - contain the assets of the application like images and static files

environmant conatin the development and production env file

favicon - favorite icon which appear on the browser tab

index.html - this is the html file which finally serve on the browser

karma.config.js - configuration file for karma which our test runner

main.ts - this is entry point for the application. this file contain a method
         bootrapmodule which point out to the root module of the application

style.css - global css file

test.ts - enrty point for your testing server



# Angular

# Modules
- Angular has its own modularity system called module or ngModule
- Every angular app must have at leave one module which is know as root module (AppModule)
- An angular module is a class with @NgModule decorator
- Angular also has build in library module which start with @angular prefix
- Built in library can be install using npm 
- A decorator function that takes single metadata object whose properties
  describe the module

- The main properties
> imports
> declaration
> bootstrap
> exports
> provider

- imports - specify the other dependend module whose exported classes are
          require by the components in you app
- declaration - specify the view classes- components, directive etc

- boostrap - specify the name of the root component. only one root module
    can have this property

- exports - a subset of declaration that will be visible and usabel in the
   component templates

- providers - specify the main app services


































































































































