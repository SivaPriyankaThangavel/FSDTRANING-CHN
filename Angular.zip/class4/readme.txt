# Component Interaction
When two component are nested then they can interact with each other

@Input
@Output

Input decorator is use when child want to accept data from the parent component using
property binding

Output decorator is use when child want to send data to the parent component using
event binding


# Services

By duplication the same data into multiple component we are
voilating software principal

1. DRY (Do not repeat yourself)
2. Single Responsiblity Principal

Angular services are singleton object which get instantiated only once during
the lifetime of an application. They contain method that maintain data throughout the life
of an application ie data does not get refereshed and is visible or avilable all the time.
The main objetive of a service is to organize and share business logic, methods or data
 and function with the different components of an angular application

# Why to use services
1. Share data accross the aplication or among all components
2. Implement application or business logic
3. External interaction or consume any third party RESTAPI service


# steps
1. define a service
2. Register a service
3. consume a service




# Dependency Injection
It is a design pattern which we use to handle dependency efficiently

DI is a coding pattern in which class receive its dependencies from the 
external sources rather tha creating them itself


DI as Framework
1. define a service
2. register with injectable
3. decalare as dependency for component

> Code without DI
> Code with DI


class Test{

 demo(){
  // code
 }

}


obj = new Test();
obj.demo();


Example:

class Engine{
}

class Tires{
}


class Car{

engine;
tires;

constructor(){
engine = new engine();

}

}


# Http service

# Observable
HTTP get request from Data Service
Receive the observable and cast it into an employee array
subscribe to the observable from component
assign the employee array to a local variable

RxJs
- REactive extension for Javascript
- External libraray to work with observable


HTTPClientModule  - app Module
HttpClient   - service which containt get/post/delete/put methods




















































