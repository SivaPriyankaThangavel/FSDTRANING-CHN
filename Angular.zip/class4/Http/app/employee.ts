interface Employee{
    code: string;
    name: string;
    gender: string;
    salary: number;
    dateOfBirth: string;
}