class Engine{

    constructor(parameter){

    }

}

class Tires{
    
}
class DIContainer{
    engine = new Engine();
    tires = new Tires();
}
class Car{
    engine;
    tires;

    constructor(engine, tires){
        this.engine = engine;
        this.tires = tires;
    }




}