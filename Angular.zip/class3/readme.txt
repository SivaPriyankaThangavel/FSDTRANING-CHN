# Template Refernce Variables

template reference variables is use to refer any particular html element and 
In form it is very usefull as it help you to get the value of the form element

# use to create template refernce variable

Example
<input value="" type="text" #myInput /

myInput.value  // value of the textbox



# Two way binding
When data flow in both direction means from component to view and from view
to the component

In simple words we can say when we declare a variable and the value keep on
updating whenever we change the value in component class or in template

Syntex
------
[] - property binding - component to template
() - event binding - template to component


[()] - two way binding - banana in a box


# Structural Directives
When we want to add or remove HTML elements

> ngIf
> ngSwitch
> ngFor


# ngIf
is use when you want to take a decision and on the basis of that you want to
add or remove html element

Syntex
-------
*ngIf - we have to start with * when ever we have to use this directive



# ngSwitch
is also use to add or remove html from the document


# ngFor
work as a loop when we want to add multiple element we can use ngFor

syntex
------
*ngFor=""


The ngFor directive that comes with the angular framework itself
we can use this directive if we want to display a dynamic list
for example: an array of elements on the screen in table


We have special variables to get
- index
- first
- last
- odd
- even
element value of the array

Problem
1. ngFor directive may perform poorly with large data set
2. A small change to the list trigger a cascade of DOM manipulations

# trackBy
using trackBy with ngFor directive we can able to recognize the changes made in the
array list and can reuse the existing DOM element and re create only the additional
element


Steps
To specify a trackBy function we first need to create one on our component
The function gets the index of the element and element itself
then we have to return the unique value of the eleemnt like code
ngFor directive track by property take fucntion name it should use to track



# Pipes
Transform data before display
build in pipes which you can use 
example
lowercase, uppercase, decimal etc

we can also create our custom pipes

Syntex
-------
{{ | <name of pipe>: <parameter or option>  }}
we can apply multiple pipes that is known as chain pipe
pass the parameter into pipe use color :
































