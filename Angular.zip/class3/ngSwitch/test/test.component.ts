import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <h1>Test Component</h1>
  <br>

  <div [ngSwitch]="color">
    <h1 *ngSwitchCase="'red'">Red color is selected</h1>
    <h1 *ngSwitchCase="'blue'">Blue color is selected</h1>
    <h1 *ngSwitchCase="'green'">Green color is selected</h1>
    <h1 *ngSwitchDefault>Not selected</h1>
  </div>

<br>
<hr>
<br>
<div [ngSwitch]="color">
    <span class="my-span" *ngSwitchCase="'red'" [style.background-color]="'red'">Hello from Switch</span>
    <span class="my-span" *ngSwitchCase="'blue'"  [style.background-color]="'blue'">Hello from Switch</span>
    <span class="my-span" *ngSwitchCase="'green'"  [style.background-color]="'green'">Hello from Switch</span>
    <span class="my-span" *ngSwitchDefault>Not selected</span>
  </div>



  

  `,
  styles: [`
    .my-span{
      width: 200px
      padding: 50px;
      border-radius: 10px;
      color: #fff

    }
  
  `]
})
export class TestComponent implements OnInit {


  public color = "blue";
  
  
  constructor() { }

  ngOnInit() {
  }

  



}
