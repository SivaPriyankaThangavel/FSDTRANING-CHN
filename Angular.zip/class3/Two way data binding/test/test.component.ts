import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <h1>Test Component</h1>
<br>

<input type="text" value="" [(ngModel)]="name"/>


  <h1>{{ name }}</h1>
  `,
  styles: [`
  
  
  `]
})
export class TestComponent implements OnInit {


  public name ="Mark Smith";

  constructor() { }

  ngOnInit() {
  }

  



}
