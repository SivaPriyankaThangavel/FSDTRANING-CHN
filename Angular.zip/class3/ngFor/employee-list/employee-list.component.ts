import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees = [];


  constructor() {
    this.employees = [
    { code: 'emp101', name: 'Mark', gender: 'Male', Salary: 5000 },
    { code: 'emp102', name: 'Watson', gender: 'Male', Salary: 5000 },
    { code: 'emp103', name: 'Stacy', gender: 'Female', Salary: 5000 },
    { code: 'emp104', name: 'Paul', gender: 'Male', Salary: 5000 }
  
    ]
   }

   onRefereshData(){
    this.employees = [
      { code: 'emp101', name: 'Mark', gender: 'Male', Salary: 5000 },
      { code: 'emp102', name: 'Watson', gender: 'Male', Salary: 5000 },
      { code: 'emp103', name: 'Stacy', gender: 'Female', Salary: 5000 },
      { code: 'emp104', name: 'Shaw', gender: 'Male', Salary: 5000 },
      { code: 'emp105', name: 'Paul', gender: 'Male', Salary: 5000 }
      ]
   }

   trackByEmpCode(index: number, employee: any): string{

   }


  ngOnInit() {
  }

}
