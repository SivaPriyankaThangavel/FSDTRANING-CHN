import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template:`
  <app-employee-list></app-employee-list>
  `,
  styles: [`
  
  `]
})
export class TestComponent implements OnInit {

  public name = "Mark Smith";
  public message = "welcome to angular training";
  public person = {
    firstName: "Mark",
    lastName: "Smith"
  }

  public date = new Date();
  
  constructor() { }

  ngOnInit() {
  }

  



}
