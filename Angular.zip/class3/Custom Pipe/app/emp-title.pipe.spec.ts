import { EmpTitlePipe } from './emp-title.pipe';

describe('EmpTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new EmpTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
