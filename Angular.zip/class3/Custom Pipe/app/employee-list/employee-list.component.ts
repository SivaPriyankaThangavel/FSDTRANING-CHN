import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees = [];


  constructor() {
    this.employees = [
    { code: 'emp101', name: 'Mark', gender: 'Male', salary: 5000, dateOfBirth: '12/12/1983' },
    { code: 'emp102', name: 'Watson', gender: 'Male', salary: 5000, dateOfBirth: '12/30/1983' },
    { code: 'emp103', name: 'Stacy', gender: 'Female', salary: 5000, dateOfBirth: '06/12/1983' },
    { code: 'emp104', name: 'Paul', gender: 'Male', salary: 5000, dateOfBirth: '03/30/1983' },
  
    ]
   }


  ngOnInit() {
  }

}
