import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators  } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveLoginComponent implements OnInit {

  rForm: FormGroup;
  username: string = "";
  password: string = "";


  constructor(private fb: FormBuilder) { 
    this.onFormSubmit();
  }

  ngOnInit() {
  }

  onFormSubmit(){
    this.rForm = this.fb.group({
      'username': [this.username, Validators.required],
      'password': [this.password, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(10)])]
    })
  }





}
