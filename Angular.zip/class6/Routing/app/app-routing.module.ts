import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { DepartmentDetailsComponent } from './department-details/department-details.component';

const routes : Routes = [    
    { path: '', redirectTo:"employee", pathMatch:'full' },
    { path: 'employee', component: EmployeeComponent  },
    { path: 'department', component: DepartmentComponent },
    { path: 'department/:id', component: DepartmentDetailsComponent},
    { path: '**', component: PageNotFoundComponent }
];



@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule{

}