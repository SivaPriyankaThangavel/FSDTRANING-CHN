import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent implements OnInit {


  topicError = true;

  public userModel = new User('', 'm@gmail.com', 99999, 'default', 'male', true);


  public topics = ['HTML', 'CSS', 'Angular'];

  constructor() { }

  ngOnInit() {
  }

  onSelected(value){
    if(value=='default'){
      this.topicError = true;
    }else{
      this.topicError = false;
    }
  }

  onSubmit(){
    console.log(this.userModel);
  }

}
