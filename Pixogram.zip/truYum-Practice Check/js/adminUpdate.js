var url_string = window.location.href; 

var url =new URL(url_string);



let name=url.searchParams.get('name');

let price=url.searchParams.get('price');

let Active=url.searchParams.get('Active');

let dataofLaunch=url.searchParams.get('dataofLaunch');

let category=url.searchParams.get('Category');

let freeDelivery=url.searchParams.get ('freeDelivery');


let nameText=document.querySelector("#name");

let priceText=document.querySelector("#price");

let activeValue=document.querySelector("#Active");

let dataofLaunchText=document.querySelector("#dol");

let categoryText=document.querySelector("#cat")

var x = document.getElementById("cat").options.length;
var d=0;
for(var i=0;i<x;i++){
    var f=categoryText[i].value;
    if(category==f){
        d=i;
        break;
    }
}

var element = document.getElementById("cat");

element.value = categoryText[d].value ;



let freeDeliveryText=document.querySelector("#delivery");


nameText.setAttribute('value',name);

priceText.setAttribute('value',price) ;




if(Active ==="Yes"){
    document.getElementById("ActiveYes").checked=true;
}
else{
    document.getElementById("ActiveNo").checked=true;
}
dataofLaunchText.setAttribute('value',dataofLaunch);

if(freeDelivery=="Yes"){
    document.getElementById("delivery").checked=true;
}
else{
    document.getElementById("delivery").checked=false;
}

document.querySelector('#save').addEventListener('click',function()

    {
    
        var name1=nameText.value;       
      
        var category1=categoryText.value;
       
        var dol1=dataofLaunchText.value;
     
       
    
        let productsStrings=localStorage.getItem('products');
        let products=JSON.parse(productsStrings);
    let product=products.find(function(product){
    
    return product.name === name1;
    })
    
    product.price=priceText.value;
    let delivery1;
    let active1;
    if(document.getElementById("delivery").checked){
        delivery1="Yes";
    }
    else{
        delivery1="No";
    }
    if(document.getElementById("ActiveYes").checked){
        active1="Yes";
    }
    else{
        active1="No";
    }

    product.dataofLaunch=dol1;


    product.freeDelivery=delivery1;
    product.Active=active1;
    product.Category=category1;
localStorage.removeItem('products');
localStorage.setItem('products',JSON.stringify(products));
window.location="C:/Users/765744/Documents/truYum-Practice Check/edit-menu-item-status.html";
    }) 
    





