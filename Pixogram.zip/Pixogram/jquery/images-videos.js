$(document).ready(function(){
    $("#images").click(function(){
      $(".s2").show();
    });
    $("#videos").click(function(){
     // $(".s2").hide();
     
    });
  });
  