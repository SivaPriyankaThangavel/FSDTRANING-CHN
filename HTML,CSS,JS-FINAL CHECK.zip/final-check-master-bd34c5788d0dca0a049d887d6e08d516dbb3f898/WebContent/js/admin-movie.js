const movies=[
    {
    title:'Avatar',boxOffice:'$2,787,965,087',active:'Yes',dataofLaunch:'15/03/2017',genre:'Science Fiction',
    hasTeaser:'Yes',pid:1
    },
    {
      title:'The Avengers',boxOffice:'$1,518,812,988',active:'Yes',dataofLaunch:'23/12/2017',genre:'Super Hero',
      hasTeaser:'No',pid:2
      },
      {
        title:'Titanic',boxOffice:'$2,187,463,944',active:'Yes',dataofLaunch:'21/08/2017',genre:'Romance',
        hasTeaser:'No',pid:3
        },
        {
          title:'Jurassic World',boxOffice:'$1,671,713,208',active:'No',dataofLaunch:'02/07/2017',genre:'Science Fiction',
          hasTeaser:'Yes',pid:4
          },
          {
            title:'Avengers End Game',boxOffice:'$2,750,760,348',active:'Yes',dataofLaunch:'02/07/2017',genre:'Superhero',
            hasTeaser:'Yes',pid:5
            }
    ];
    let movieFromStorage=localStorage.getItem('movies');
    if(movieFromStorage === null)
    {
        localStorage.setItem('movies',JSON.stringify(movies));
    }
   
    
    movieFromStorage=JSON.parse(movieFromStorage)
    const renderProducts=function(movies)
    {
                    let tabE1=document.querySelector("#mov-tab");
                    
                    
                           movieFromStorage.forEach(function (movie) {
                                    let trow1=document.createElement("tr");
                                    let tcol1=document.createElement("td");
                                    tcol1.textContent=movie.title;
                                    trow1.appendChild(tcol1);
                                    
                                    let tcol2=document.createElement("td");
                                    tcol2.textContent=movie.boxOffice;
                                    trow1.appendChild(tcol2);
                    
                                    let tcol3=document.createElement("td");
                                    tcol3.textContent=movie.active;
                                    trow1.appendChild(tcol3);
                                    
                                    
                                    let tcol4=document.createElement("td");
                                    tcol4.textContent=movie.dataofLaunch;
                                    trow1.appendChild(tcol4);
                                    
                                    
                                    let tcol5=document.createElement("td");
                                    tcol5.textContent=movie.genre;
                                    trow1.appendChild(tcol5);
                                    
                                    
                                    let tcol6=document.createElement("td");
                                    tcol6.textContent=movie.hasTeaser;
                                    trow1.appendChild(tcol6);
                                    
                                    let link=document.createElement("a");
                                    link.setAttribute('pid','link');
                                   
                                    link.href = "edit-movie.html?id=" +movie.pid +
                                      "&title=" + movie.title + 
                                      "&boxOffice=" + movie.boxOffice +
                                      "&active="+ movie.active+
                                      "&dataofLaunch="+movie.dataofLaunch +
                                      "&genre="+movie.genre +
                                      "&hasTeaser="+movie.hasTeaser;

                                    link.textContent="Edit";
                                    let tcol7=document.createElement("td");
                                    tcol7.appendChild(link);
     
                                    trow1.appendChild(tcol7);
                                    
                                    tabE1.appendChild(trow1);
                                    
                    })
                    
                    
    }
    renderProducts(movieFromStorage);
     
  
     
     
    