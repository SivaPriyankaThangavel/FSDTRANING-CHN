var url_string = window.location.href; 

var url =new URL(url_string);
console.log(url)


let title=url.searchParams.get('title');

let boxOffice=url.searchParams.get('boxOffice');

let active=url.searchParams.get('active');

let dataofLaunch=url.searchParams.get('dataofLaunch');

let genre=url.searchParams.get('genre');

let hasTeaser=url.searchParams.get ('hasTeaser');


let titleText=document.querySelector("#title");

let boxOfficeText=document.querySelector("#gross");

let activeValue=document.querySelector("#active");

let dataofLaunchText=document.querySelector("#dol");

let genreText=document.querySelector("#gen")

var x = document.getElementById("gen").options.length;
var d=0;
for(var i=0;i<x;i++){
    var f=genreText[i].value;
    if(genre==f){
        d=i;
        break;
    }
}

var element = document.getElementById("gen");

element.value = genreText[d].value ;



let hasTeaserText=document.querySelector("#teaser");


titleText.setAttribute('value',title);

boxOfficeText.setAttribute('value',boxOffice) ;




if(active ==="Yes"){
    document.getElementById("ActiveYes").checked=true;
}
else{
    document.getElementById("ActiveNo").checked=true;
}
dataofLaunchText.setAttribute('value',dataofLaunch);

if(hasTeaser=="Yes"){
    document.getElementById("teaser").checked=true;
}
else{
    document.getElementById("teaser").checked=false;
}

document.querySelector('#save').addEventListener('click',function()

    {
    
        var title1=titleText.value;    
    
      
        var genre1=genreText.value;
       
        var dol1=dataofLaunchText.value;
     
       
    
        let moviesStrings=localStorage.getItem('movies');
        let movies=JSON.parse(moviesStrings);
    let movie=movies.find(function(movie){
    
    return movie.title === title1;
    })
   
movie.boxOffice=boxOfficeText.value;
let teaser1;
let active1;
if(document.getElementById("teaser").checked){
    teaser1="Yes";
}
else{
    teaser1="No";
}
if(document.getElementById("ActiveYes").checked){
    active1="Yes";
}
else{
    active1="No";
}
movie.dataofLaunch=dol1;


movie.hasTeaser=teaser1;
movie.active=active1;
movie.genre=genre1;
localStorage.removeItem('movies');
localStorage.setItem('movies',JSON.stringify(movies));
if(title1==""){
    window.alert("Title is required."); 
       
      
}
if(title1.length < 2 || title1.length > 100)
    {  	
        window.alert("Name length should be between 2 to 30 characters");  		
          
     }
 if(boxOffice.value=""){
        window.alert("Box Office is required"); 

     }
     if( isNaN(boxOffice.value) ){
        window.alert("Box Office has to be a number."); 
        
    }
    if(dol1==""){
        window.alert(" Date of Launch is required ") ;
    }
    var strUser = genreText.options[ genreText.selectedIndex].text;
    if(strUser==0){
         window.alert("Select one genre");
    }

window.location="file:///D:/final-check/WebContent/edit-movie-status.html ";
 
    }) 
    


