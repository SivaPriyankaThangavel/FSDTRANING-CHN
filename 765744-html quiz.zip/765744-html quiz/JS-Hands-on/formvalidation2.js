document.getElementById("button").addEventListener("click",function()                                 
{ 
    var name = document.forms["RegForm"]["Name"].value;               
    
    var password= document.forms["RegForm"]["Password"].value;  
  
   
 if (name== "")                                  
    { 
        window.alert("Name cannot be empty"); 
        name.focus(); 
        return false; 
    } 
 
    if( /[0-9\-\/]/.test( name ) ){
        window.alert("Name cannot have numbers"); 
        name.focus(); 
        return false; 
    }
    if( /[^a-zA-Z0-9\-\/]/.test( name ) ){
        window.alert("Name cannot have special characters"); 
        name.focus(); 
        return false; 
    }
    if(name.length < 2 || name.length > 30)
    {  	
        window.alert("Name length should be between 2 to 30 characters");  		
        name.focus();
        return false;  
     }
     
      
   
    
    if (password == "")                        
    { 
        window.alert("Password cannot be empty"); 
        password.focus(); 
        return false; 
    } 
   
    
    return true; 
});