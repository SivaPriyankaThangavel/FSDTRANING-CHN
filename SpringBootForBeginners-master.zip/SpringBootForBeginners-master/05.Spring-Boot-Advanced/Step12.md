## What You Will Learn during this Step:
- Spring Initializr
- https://start.spring.io
- Create a few projects!

## Exercises
- Create more projects with Spring Initializr and play around with it!
