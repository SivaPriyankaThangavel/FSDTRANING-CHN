## What we will do:
- Lets discuss about Architecture of web applications
