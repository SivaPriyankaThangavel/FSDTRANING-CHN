import java.util.*;  
public class LabAlloc{
public static void main(String args[]){  
			Scanner in = new Scanner(System.in);  
			System.out.println("Enter x");
         	int x =in.nextInt();
			System.out.println("Enter y");
        	int y =in.nextInt();;
			System.out.println("Enter z");
			int z=in.nextInt();
			if(x < y && x <z)
				{		
					System.out.println("L1 has the minimal seating capacity");
				}
			else if(y < z)
				{
					System.out.println("L2 has the minimal seating capacity");
				}
			else
				{
					System.out.println("L3 has the minimal seating capacity");
				}	
		
			
          }  
} 