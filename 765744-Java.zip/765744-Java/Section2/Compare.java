import java.util.*;  
public class Compare{
public static void main(String args[]){  
			Scanner in = new Scanner(System.in);  
			System.out.println("Enter the first number");
         	int x =in.nextInt();
			System.out.println("Enter the second number ");
        	int y =in.nextInt();;
			
			if(x  == y )
				{		
					System.out.println(x+" is equal to "+y);
				}
			else if(x < y)
				{
					System.out.println(x+" is less than "+y);
				}
			else
				{
					System.out.println(x+" is greater than "+y);
				}	
		
			
          } 
} 