import java.util.*;  
public class DisCal{
public static void main(String args[]){  
          Scanner in = new Scanner(System.in);  
           System.out.println("Price of item 1 :");
          float i1=in.nextFloat();
          System.out.println("Price of item 2 : ");
           float  i2=in.nextFloat();
          System.out.println("Discount in percentage :");
		int z=in.nextInt();
		float tot=i1+i2;
		 float discount = (tot * z) / 100;
		float dif= tot - discount;
		 System.out.println("");
			System.out.printf("Total amount : %.2f$",tot);
			 System.out.println("");
			System.out.printf("Discounted amount : %.2f$",dif);
			 System.out.println("");
			System.out.printf("Saved amount :  %.2f$",discount);
          }  
} 