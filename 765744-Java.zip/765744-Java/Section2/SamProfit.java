import java.util.*;  
public class SamProfit {  
public static void main(String args[]){  
          Scanner in = new Scanner(System.in);  
           System.out.print("Enter the number of dozens of toys purchased"); 
          double   x=in.nextInt();
          System.out.println("\n Enter the price per dozen"); 
           double  y=in.nextInt();
          System.out.println("Enter the selling price of 1 toy"); 
			 double   z=in.nextInt();
			double  cp=y/12;
			 double   p=z-cp;
			 double  pp=(p/cp)*100;
			 System.out.printf("Sam's profit percentage is %.2f percent",pp);
          }  
}  