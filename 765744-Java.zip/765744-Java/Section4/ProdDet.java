import java.util.*;
public class ProdDet
{ 
	int productId;
    String pname; 
    String sname; 
  
   
  
   
    public	ProdDet(int productId, String	pname, 
                   String sname ) 
    { 
        this.productId= productId; 
        this.pname= pname; 
		this.sname= sname; 
  
   
    public int getProductId(){ 
        return productId; 
    } 
	public setProductId(int productId){ 
	this.productId= productId; 
	}
	
   public String getPname(){ 
        return pname; 
    } 
	public setPname(String	pname){ 
	this.pname= pname;  
	}
  
   public String getPname(){ 
        return pname; 
    } 
	public setPname(String	pname){ 
	this.pname= pname;  
	}
   
  
   
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ 
               ".\nMy breed,age and color are " + 
               this.getBreed()+"," + this.getAge()+ 
               ","+ this.getColor()); 
    } 
  
    public static void main(String[] args) 
    { 
        Dog tuffy = new Dog("tuffy","papillon", 5, "white"); 
        System.out.println(tuffy.toString()); 
    } 
} 