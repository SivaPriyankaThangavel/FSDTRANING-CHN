import java.util.*;
import java.io.*;
 class Product
{ 
private long  id; 
private String productName ; 
private   String supplierName;
public Product(){

}
public Product(long id,String productName,String supplierName){
       this.id = id; 
        this.productName=productName;
         this.supplierName=supplierName;
    
}
public void setId(long  id) 
    { 
        this.id = id; 
    } 
public long getId() 
    { 
        return id; 
    } 
public void setPname(String productName) 
    { 
       this.productName=productName;
    } 
public String getPname() 
    { 
        return productName; 
    } 
    public void setSname(String supplierName) 
    { 
       this.supplierName=supplierName;
    } 
public String getSname() 
    { 
        return supplierName; 
    } 
    public void display(){
         System.out.println("Product Id is "+getId()); 
         System.out.println("Product Name is "+getPname()); 
         System.out.println("Supplier Name is "+getSname()); 
    }
} 


public class ProductDetails2{ 
public static void main(String args[])  throws IOException 
    {   BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); ;
       
         System.out.println("Enter the product id"); 
         long id=Long.parseLong(sc.readLine());
         System.out.println("Enter the product name "); 
        String pname=sc.readLine();
         System.out.println("Enter the supplier name  "); 
        String sname=sc.readLine();
         Product s = new Product(id,pname,sname); 
      s.display();
       

    } 
    
} 