import java.util.*;
import java.io.*;
 class Product
{ 
private long  id; 
private String productName ; 
private   String supplierName;

public void setId(long  id) 
    { 
        this.id = id; 
    } 
public long getId() 
    { 
        return id; 
    } 
public void setPname(String productName) 
    { 
       this.productName=productName;
    } 
public String getPname() 
    { 
        return productName; 
    } 
    public void setSname(String supplierName) 
    { 
       this.supplierName=supplierName;
    } 
public String getSname() 
    { 
        return supplierName; 
    } 
} 


public class ProductDetails{ 
public static void main(String args[])  throws IOException 
    {   BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); ;
        Product s = new Product(); 
         System.out.println("Enter the product id"); 
         long id=Long.parseLong(sc.readLine());
         System.out.println("Enter the product name "); 
        String pname=sc.readLine();
         System.out.println("Enter the supplier name  "); 
        String sname=sc.readLine();
        s.setId(id);
        s.setPname(pname);
        s.setSname(sname);
        System.out.println("Product Id is "+s.getId()); 
         System.out.println("Product Name is "+s.getPname()); 
         System.out.println("Supplier Name is "+s.getSname()); 

    } 
} 