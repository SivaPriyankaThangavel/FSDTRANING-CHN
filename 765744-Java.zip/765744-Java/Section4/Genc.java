 import java.util.*;
import java.io.*;
 class Student
{ 
private long employeeId; 
private String name ; 

private static final String COHORT_CODE = "CHNAJ19004"; 
public Student(){

}
public  Student(long employeeId,String name){
       this. employeeId =  employeeId; 
        this.name=name;
      
    
}
public void setId(long  id) 
    { 
        this. employeeId=  employeeId; 
    } 
public long getId() 
    { 
        return employeeId; 
    } 
public void setName(String name) 
    { 
       this.name=name;
    } 
public String getName() 
    { 
        return name; 
    } 
    
    public void display(){
        System.out.println(employeeId+" "+name +" "+COHORT_CODE); 
         
    }
} 


public class Genc{ 
public static void main(String args[])  throws IOException 
    {   BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
        System.out.println("Enter the number of GenCs "); 
    int i=Integer.parseInt(sc.readLine());
    Student[] s=new Student[i];
    for(int j=0;j<i;j++){
         System.out.println("Enter Employee Id"); 
         long id=Long.parseLong(sc.readLine());
         System.out.println("Enter Name "); 
          String name=sc.readLine();
      s[j]= new Student(id,name);
        
    }
    for(int j=0;j<i;j++){
        s[j].display();
        
        
    }
   
    
} 
}