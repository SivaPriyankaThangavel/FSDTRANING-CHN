
import java.util.*;

public class DayofWeek1
{ 
    public static void main(String[] args) 
    { 
       
        Scanner sc=new Scanner(System.in);
         
		System.out.println("Enter the day number"); 
        int no=sc.nextInt();
		String	t[] =new String[7];
		t[0]="Sat";
		t[1]="Sun";
		t[2]="Mon";
		
		t[3]="Tue";
		t[4]="Wed";
		t[5]="Thu";
		t[6]="Fri";
		
		
		System.out.println("Day of the week is "+t[no]);
    } 
} 