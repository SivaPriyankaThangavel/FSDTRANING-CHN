
import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStreamReader; 
public class Replace
{ 
    public static void main(String[] args) throws IOException  
    { 
       
        BufferedReader reader =  
                   new BufferedReader(new InputStreamReader(System.in)); 
         
		System.out.println("Enter the content of the document"); 
        String name = reader.readLine(); 
		System.out.println("Enter the old name of the company"); 
		BufferedReader reader1	=  
                   new BufferedReader(new InputStreamReader(System.in)); 
      
         String name1= reader1.readLine(); 
		 System.out.println("Enter the new name of the company"); 
		 BufferedReader reader2	=  
                   new BufferedReader(new InputStreamReader(System.in)); 
      
         String name2= reader2.readLine(); 
		 
		String replaceString=name.replaceAll(name1,name2);
		System.out.println(replaceString);  
    } 
} 