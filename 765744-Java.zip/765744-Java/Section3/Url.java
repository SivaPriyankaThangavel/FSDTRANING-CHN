
import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStreamReader; 
public class Url
{ 
    public static void main(String[] args) throws IOException  
    { 
       
        BufferedReader reader =  
                   new BufferedReader(new InputStreamReader(System.in)); 
         
		System.out.println("Enter the string"); 
        String name = reader.readLine(); 
		System.out.println("Enter the start string"); 
		BufferedReader reader1	=  
                   new BufferedReader(new InputStreamReader(System.in)); 
      
         String name1= reader1.readLine(); 
		if(name.startsWith(name1)){
			
			System.out.println("\""+name+"\""+" starts with \"https\"");
			 
		 }
		 else{
			
			System.out.println("\""+name+"\""+" does not starts with \"https\"");
			 
		 }
    } 
} 