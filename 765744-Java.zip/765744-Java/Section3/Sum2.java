import java.util.Scanner;
public class	Sum2
{
    public static void main(String[] args) 
    {
        int n, sum = 0;
        Scanner s = new Scanner(System.in);
       
        n = s.nextInt();
        int a[] = new int[n];
       
       int i=0;
	   while(i<n)
        {
            a[i] = s.nextInt();
            
			i++;
        }
		for(int a1:a){
			sum = sum + a1;
		}
        System.out.println(sum);
    }
}