
import java.util.*;

public class DayofWeek
{ 
    public static void main(String[] args) 
    { 
       
        Scanner sc=new Scanner(System.in);
         
		System.out.println("Enter the day number"); 
        int no=sc.nextInt();
		String	t[] = {	"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
		
		System.out.println("Day of the week is "+t[no]);
    } 
} 