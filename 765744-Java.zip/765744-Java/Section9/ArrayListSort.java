import java.util.*;
public class ArrayListSort{
    public static void main(String args[]){
        ArrayList<Integer> al = new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int total = 0;
        float  avg;
        int i;
        for(i=0;i<n;i++){
            al.add(sc.nextInt());
            
        }
        Collections.sort(al); 
        for(i=0;i<n;i++){
           System.out.println(al.get(i));
            
        }
        
       
    }
}