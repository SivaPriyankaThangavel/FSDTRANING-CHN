import java.util.*;
import java.io.*;
class Player{
    private String name;
    private String country;
    private String skill;
    public Player(String name, String country,String skill){
        this.name=name;
        this.country=country;
        this.skill=skill;
    }
    public String getName()  
    { 
      return name; 
    } 
   
    public String getCountry()  
    { 
      return country; 
    } 
   
    public String getSkill(){
        return skill;
    }
    public void setName(String name) 
    { 
    this.name=name;

    } 
     
   public void setCountry(String country) 
    { 
    this.country=country;
     
    } 
     
    public void setSkill(String skill) 
    { 
    this.skill=skill;
     
    } 

    public String toString(){ 
        return String.format("%-15s %-15s %-15s",name, country, skill);
    }
     
}
 
 class PlayerBO{
    void displayAllPlayerDetails(ArrayList playerList) {
for(Object i:playerList){
    System.out.println(i);
}
    
}
 }
public class PlayerDetails{
    public static void main(String args[]) throws IOException {
      ArrayList<Player>al=new ArrayList<>();
      PlayerBO  pb=new PlayerBO();
        System.out.println("Enter the number of player");
       
  BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); ;
        int p=  Integer.parseInt(sc.readLine());
     
        Player pl[]=new Player[p];
        for(int i=0;i<p;i++){
        System.out.println("Enter the player name");
        String pname=sc.readLine();
        System.out.println("Enter the country name");
        String cname=sc.readLine();
        System.out.println("Enter the skill");
        String sname=sc.readLine();
        pl[i]=new Player(pname,cname,sname);  
        al.add(pl[i]);         
    }
    pb.displayAllPlayerDetails(al);
    }
}