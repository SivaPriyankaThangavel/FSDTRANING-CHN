import java.util.*;
public class ArrayListSum{
    public static void main(String args[]){
        ArrayList<Integer> al = new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int total = 0;
        float  avg;
        int i;
        for(i=0;i<n;i++){
            al.add(sc.nextInt());
            total+=al.get(i);
        }
        
        avg = (float)total / n;
        System.out.println(total);
        System.out.printf("%.2f",avg);
    }
}