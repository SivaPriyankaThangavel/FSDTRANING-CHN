import java.util.*;
public class Divide
{
   public static void main(String args[])
   {	Scanner sc=new Scanner(System.in);
	    System.out.println ("Enter the 2 numbers");
		  int num1, num2;
      try{
       num1=sc.nextInt();
         num2=sc.nextInt(); 
		 int q=num1/num2;
		 System.out.printf("The quotient of %d/%d =	%d",num1,num2,q);
 System.out.println();
        
      }
      catch(ArithmeticException e){
         System.out.println ("DivideByZeroException caught ");
      }
	   finally{System.out.println("Inside finally block");}  
   }
}