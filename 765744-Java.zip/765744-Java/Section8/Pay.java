public	class Pay{
    public static void main(String[] args) {        
        int[] arrayNumbers = {1, 2, 3};
System.out.println(arrayNumbers[10]);
    }
}