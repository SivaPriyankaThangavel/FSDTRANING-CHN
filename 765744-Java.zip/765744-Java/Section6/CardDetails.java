import java.io.*;
import java.util.*;
abstract class Card
{
    String holderName;
    String cardNumber;
    String expiryDate;
    Card(String holderName,String cardNumber,String expiryDate)
    {
        this.holderName=holderName;
        this.cardNumber=cardNumber;
        this.expiryDate=expiryDate;
    }
    public String getHolderName()
    {
        return holderName;
    }
    public void setHolderName(String holderName)
    {
        this.holderName=holderName;
    }
    public String getCardNumber()
    {
        return cardNumber;
    }
    public void setCardNumber(String cardNumber)
    {
        this.cardNumber=cardNumber;
    }
    public String getExpiryDate()
    {
        return expiryDate;
    }
    public void setExpiryDate(String expiryDate)
    {
        this.expiryDate=expiryDate;
    }
}
class MembershipCard extends Card
{
    private int rating;
    MembershipCard(String holderName,String cardNumber,String expiryDate,int rating)
    {   
        super(holderName,cardNumber,expiryDate);
        this.rating=rating;
    }
    public int getRating()
    {
        return rating;
    }
    public void setRating(int rating)
    {
        this.rating=rating;
    }
} 
class PaybackCard extends Card
{
    int pointsEarned;
    double totalAmount;
    PaybackCard(String holderName,String cardNumber,String expiryDate,int pointsEarned,double totalAmount)
    {
       super(holderName,cardNumber,expiryDate);
        this.pointsEarned=pointsEarned;
        this.totalAmount=totalAmount;
    }
    public int getPointsEarned()
    {
        return pointsEarned;
    }
    public void setPointsEarned(int pointsEarned)
    {
        this.pointsEarned=pointsEarned;
    }
    public double getTotalAmount()
    {
        return totalAmount;
    }
    public void setTotalAmount(double totalAmount)
    {
        this.totalAmount=totalAmount;
    }
}
public class CardDetails
{
    public static void main(String args[])
    {
        int option;
        String cardDetail;
         int pointsEarned;
        double totalAmount;
        int rating;
        String[] array=new String[5];
        Scanner sc=new Scanner(System.in);
        System.out.println("Select the Card\n1.Payback Card\n2.Membership Card ");
        option=sc.nextInt();
        sc.nextLine();
        if(option ==1)
        {
            System.out.println("Enter the Card Details:"); 
            cardDetail=sc.nextLine();
            System.out.println("Enter points in card");
            pointsEarned=sc.nextInt();
            System.out.println("Enter Amount");
            totalAmount=sc.nextDouble();
            array=cardDetail.split("\\|");
            PaybackCard p=new PaybackCard(array[0],array[1],array[2],pointsEarned,totalAmount);
            System.out.println(p.getHolderName()+"'s Payback Card Details:");
            System.out.println("Card Number "+p.getCardNumber()+"\nPoints Earned "+p.getPointsEarned()+"\nTotal Amount "+p.getTotalAmount());

        }
        if(option == 2)
        {
            System.out.println("Enter the Card Details:"); 
            cardDetail=sc.nextLine();
            System.out.println("Enter rating in card ");
            rating=sc.nextInt();
            array=cardDetail.split("\\|");
            MembershipCard mp=new MembershipCard(array[0],array[1],array[2],rating);
            System.out.println(mp.getHolderName()+"'s Membership Card Details:");
            System.out.println("Card Number "+mp.getCardNumber()+"\nRating "+mp.getRating());       
        
        }
    }
}