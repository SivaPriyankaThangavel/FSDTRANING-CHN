import java.util.*;
import java.io.*;
class Delivery{
void displayDeliveryDetails(String bowler, String batsman) {
	String name[] = bowler.split(" ");
	String name1[]=batsman.split(" ");
	System.out.println("Player details of the delivery: ");
	System.out.println("Bowler : "+name[1]);
	System.out.println("Batsman : "+name1[1]);
	
}
void displayDeliveryDetails(Long runs) {
	
	System.out.println("Number of runs scored in the delivery : "+runs);
	if(runs==4){
		System.out.println("It is a boundary.");
	}
	if(runs==6){
	System.out.println("It is a Sixer.");
	}
	}
}
public class Cricket {
	public static void main(String args[])throws IOException
	{
		BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
        System.out.println("1.Player details of the delivery ");
        System.out.println("2.Run details of the delivery ");
		 int l=Integer.parseInt(sc.readLine());
		 Delivery d=new Delivery();
		 
		switch(l){
		case 1:
			  System.out.println("Enter the bowler name ");
			  String bname=sc.readLine();
			  System.out.println("Enter the batsman name  ");
			  String batman=sc.readLine();
			 d. displayDeliveryDetails(bname,batman);
			  break;
		case 2:
			  System.out.println("Enter the number of runs  ");
			  
			Long ru=Long.parseLong(sc.readLine());
			 d. displayDeliveryDetails(ru);
			  break;
			      
}
	}
}