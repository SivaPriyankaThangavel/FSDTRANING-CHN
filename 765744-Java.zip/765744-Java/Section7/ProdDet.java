import java.util.*;
import java.io.*;
 class Product
{ 
private long  id; 
private String productName ; 
private   String supplierName;

public void setId(long  id) 
    { 
        this.id = id; 
    } 
public long getId() 
    { 
        return id; 
    } 
public void setPname(String productName) 
    { 
       this.productName=productName;
    } 
public String getPname() 
    { 
        return productName; 
    } 
    public void setSname(String supplierName) 
    { 
       this.supplierName=supplierName;
    } 
public String getSname() 
    { 
        return supplierName; 
    } 
	@Override
    public String toString() { 
        return String.format(id +":"+productName +"	:"+supplierName);
    } 
} 


public class ProdDet{ 
public static void main(String args[])  throws IOException 
    {   BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); ;
        Product s = new Product(); 
         System.out.println("Enter the product id"); 
         long id=Long.parseLong(sc.readLine());
         System.out.println("Enter the product name "); 
        String pname=sc.readLine();
         System.out.println("Enter the supplier name  "); 
        String sname=sc.readLine();
        s.setId(id);
        s.setPname(pname);
        s.setSname(sname);
        System.out.println(s); 
		  System.out.println("Invoking getClass() method :"+s.getClass());
    } 
} 