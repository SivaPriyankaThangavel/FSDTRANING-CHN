import java.util.*;
import java.io.*;
 class Product
{ 
private long  id; 
private String productName ; 
private   String supplierName;

public void setId(long  id) 
    { 
        this.id = id; 
    } 
public long getId() 
    { 
        return id; 
    } 
public void setPname(String productName) 
    { 
       this.productName=productName;
    } 
public String getPname() 
    { 
        return productName; 
    } 
    public void setSname(String supplierName) 
    { 
       this.supplierName=supplierName;
    } 
public String getSname() 
    { 
        return supplierName; 
    } 
	public void display(){
		System.out.println("Product Id is "+getId()); 
         System.out.println("Product Name is "+getPname()); 
         System.out.println("Supplier Name is "+getSname()); 
	}
	public boolean equals(Object obj)
    {
        if (this.getClass() != obj.getClass())
        {
            return false;
        } 
        Product pro2 = (Product) obj;
        if (this.id != pro2.id)
        {
            return false;
        } 
        if (!this.productName.equals(pro2.productName))
        {
            return false;
        } 
        if (!this.supplierName.equals(pro2.supplierName)) 
        {
            return false;
        }
            return true;
    }

} 


public class ProductDetails{ 
public static void main(String args[])  throws IOException 
    {   BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); ;
        Product s1= new Product(); 
		Product s2=new Product();
         System.out.println("Enter the product id"); 
         long id1=Long.parseLong(sc.readLine());
         System.out.println("Enter the product name "); 
        String pname1=sc.readLine();
         System.out.println("Enter the supplier name  "); 
        String sname1=sc.readLine();
       s1.setId(id1);
       s1.setPname(pname1);
       s1.setSname(sname1);
	   System.out.println("Enter the product id"); 
         long id2=Long.parseLong(sc.readLine());
         System.out.println("Enter the product name "); 
        String pname2=sc.readLine();
         System.out.println("Enter the supplier name  "); 
        String sname2=sc.readLine();
       s2.setId(id2);
       s2.setPname(pname2);
       s2.setSname(sname2);
      
		if (s1.equals(s2)) { 
			 s1.display();
            System.out.println("The two products are the same"); 
        } else { 
		s2.display();
            System.out.println("The two products are different"); 
        }
		
		
		

    } 
} 