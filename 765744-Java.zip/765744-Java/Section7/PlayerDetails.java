import java.io.*;
import java.util.*;
interface IPlayerStatistics{
	public void displayPlayerStatistics() ;
}
abstract class Player{
protected String name;
protected String teamName;
protected int noOfMatches;
public Player(String name,String teamName,int noOfMatches)
{
this.name=name;
this.teamName=teamName;
this.noOfMatches=noOfMatches;	
}
}
class CricketPlayer extends Player implements IPlayerStatistics{
private int  totalRunsScored;
private int   noOfWicketsTaken;
public CricketPlayer(String name,String teamName,int noOfMatches,int  totalRunsScored,int  noOfWicketsTaken){
super(name,teamName,noOfMatches);
this.name=name;
this.teamName=teamName;
this.noOfMatches=noOfMatches;	
this.totalRunsScored=totalRunsScored;
this.noOfWicketsTaken=noOfWicketsTaken;


}
public void displayPlayerStatistics(){
System.out.println("Player Details");
System.out.println("Player name : "+name);
System.out.println("Team name : "+teamName);
System.out.println("Noof matches : "+noOfMatches);
System.out.println("Total runsscored : "+totalRunsScored);
System.out.println("No of wickets taken :  "+noOfWicketsTaken);
}

}
class HockeyPlayer extends Player implements IPlayerStatistics{
	private String 	position;
	private int  noOfGoals;
	public HockeyPlayer(String name,String teamName,int noOfMatches,String 	position,int  noOfGoals){
super(name,teamName,noOfMatches);
	this.name=name;
this.teamName=teamName;
this.noOfMatches=noOfMatches;	
this.position=position;
this.noOfGoals=noOfGoals;


}
public void displayPlayerStatistics(){
System.out.println("Player Details");
System.out.println("Player name : "+name);
System.out.println("Team name : "+teamName);
System.out.println("Noof matches : "+noOfMatches);
System.out.println("Position  :  "+position);
System.out.println("No of goals taken  :  "+noOfGoals);
}

}
public class PlayerDetails{
	public static void main(String args[])  throws IOException
	{
	 BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
    System.out.println("Menu\n1.Cricket Player Details \n2.Hockey Player Details ");
	 System.out.println("Enter choice");
	 int ch=Integer.parseInt(sc.readLine());
	 switch(ch){
		 case 1:
		       System.out.println("Enter player name"); 
			   String pname=sc.readLine();
			    System.out.println("Enter team name "); 
				String tname=sc.readLine();
				System.out.println("Enter number of matches played "); 
				int	mplay=Integer.parseInt(sc.readLine());
				System.out.println("Enter total runs scored "); 
				int	runs=Integer.parseInt(sc.readLine());
				System.out.println("Enter total number of wickets taken "); 
				int	w=Integer.parseInt(sc.readLine());
				CricketPlayer cp=new CricketPlayer(pname,tname,mplay,runs,w);
				cp.displayPlayerStatistics();
				break;
		case 2:
		       System.out.println("Enter player name"); 
			   String pname1=sc.readLine();
			    System.out.println("Enter team name "); 
				String tname1=sc.readLine();
				System.out.println("Enter number of matches played "); 
				int	mplay1=Integer.parseInt(sc.readLine());
				System.out.println("Enter the position "); 
				String p=sc.readLine();
				System.out.println("Enter total number of goals taken"); 
				int	g=Integer.parseInt(sc.readLine());
				HockeyPlayer hp=new HockeyPlayer( pname1,tname1,mplay1,p,g);
				hp.displayPlayerStatistics();
				break;
	 }
	}
}