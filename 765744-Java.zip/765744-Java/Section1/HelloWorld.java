import java.util.*;
public class HelloWorld{
    public static void main(String ars[]){
        System.out.println("Hello World");
    }
}