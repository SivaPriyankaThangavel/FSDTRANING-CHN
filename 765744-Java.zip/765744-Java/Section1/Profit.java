import java.util.*;
public class Profit{
    public static void main(String ars[]){
      double buying_price=20.54;
      double selling_price=30.50;
      System.out.printf("Buying price is %.2f",buying_price);
      
      System.out.printf("\nSelling price is %.2f",selling_price);
    }
}