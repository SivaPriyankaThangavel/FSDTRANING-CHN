import java.util.*;
import java.io.*;
import java.text.DecimalFormat;

class Shape{
	 public  static DecimalFormat df2 = new DecimalFormat("#.##");
    protected String shapeName; 
    public Shape(String shapeName){
        this.shapeName=shapeName;
    }
    public double calculateArea(){
		
        return 0.0;
    }
}

class Rectangle extends Shape{
    private int length;
    private int breadth;
public Rectangle(int length,int breadth){
    super("Rectangle");
    this.length=length;
    this.breadth=breadth;
}public double calculateArea(){
        double re=(float)length*breadth;
		 
		
        return re;
    }
}
class Square extends Shape{
private int side;
public Square(int side){
super("Square");
this.side=side;
}
public double calculateArea(){
        double sq=(float)side*side;
        return sq;
    }
}
class Circle extends Shape{
private int radius;
public  Circle(int radius){
super("Circle");
this.radius=radius;
}
public double calculateArea(){
        double cir=(float)(radius*radius*3.14);
        return cir;
    }
}
public class ShapeProg{
    public static void main(String a[]) throws IOException
    {		
         Shape shape;
         System.out.println("1. Rectangle");
        System.out.println("2. Square ");
        System.out.println("3. Circle ");
         System.out.println("Area Calculator --- Choose your shape ");
         BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
        int ch=Integer.parseInt(sc.readLine());
        switch(ch){
            case 1:
                     System.out.println("Enter length and breadth:");
                      int l=Integer.parseInt(sc.readLine());
                       int b=Integer.parseInt(sc.readLine());
                     
                       Rectangle rect = new Rectangle(l,b);
                        shape=rect;
						double re=shape.calculateArea();
						System.out.printf("Area of Rectangle is: %.2f",re);
						break;
             case 2:
			 
					System.out.println("Enter side:");
                      int s=Integer.parseInt(sc.readLine());
                      
                       Square squ=new Square(s);
                        shape=squ;
						double se=shape.calculateArea();
						 System.out.printf("Area of Square is: %.2f",se);
						break;
						
			case  3:
			 
					System.out.println("Enter Radius:");
                      int ra=Integer.parseInt(sc.readLine());
                      
                      Circle c=new Circle(ra);
                        shape=c;
						double cle=shape.calculateArea();
						System.out.printf("Area of Square is: %.2f",cle);
						break;
        }
    }
}
