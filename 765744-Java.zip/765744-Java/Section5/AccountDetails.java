import java.util.*;
import java.io.*;
 class Account
{
    private String accountNumber; 
    private int balance;
 

    public Account()
    {
        
    }

    public Account(String accountNumber, int balance)
    {
       this.accountNumber=accountNumber;
       this.balance=balance;

    } 

  public void deposit(int transactionAmount) 
    {
        balance=balance+transactionAmount;
    }

   public void withdraw(int transactionAmount) 
    { 
       
       
       if(balance>=transactionAmount){
          balance=balance-transactionAmount;
           
       }

    }
   
    
    public int getBalance()
    {
        return balance;
    }

     public void displayBalance()
    {   
         System.out.println("Your balance after the transaction is: "+balance);
  
    
    }


}


public class AccountDetails
{
    public static void main (String[] args) throws IOException 
    {
        
    BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
        System.out.println("Enter the Account Number "); 
        String ano=sc.readLine();
        System.out.println("Enter the Account Balance"); 
        int bal=Integer.parseInt(sc.readLine());
         System.out.println("Enter 1 to deposit an amount, 2 to withdraw an amount");
        int c=Integer.parseInt(sc.readLine());
         Account acc1 = new Account(ano,bal);
        if(c==1){
            System.out.println("Enter the amount to deposit ");
            int dep=Integer.parseInt(sc.readLine());
            acc1.deposit(dep);

        }
        if(c==2){
            System.out.println("Enter the amount to withdraw ");
            int with=Integer.parseInt(sc.readLine());
            acc1.withdraw(with);
        }
      
       acc1.displayBalance(); 
       
    }

}