import java.io.*;
import java.util.*;
import java.io.FileWriter;
public class Main2{
	public static void main(String args[])  throws IOException
	{
	 BufferedReader sc = new BufferedReader(new
        InputStreamReader(System.in)); 
  
	
		       System.out.println("Enter the name of the player "); 
			   String pname=sc.readLine();
			    System.out.println("Enter the team name "); 
				String tname=sc.readLine();
				System.out.println("Enter number of matches played "); 
				int	mplay=Integer.parseInt(sc.readLine());
				FileWriter csvWriter = new FileWriter("player.csv");
csvWriter.append("Player Name");
csvWriter.append(",");
csvWriter.append("Team Name");
csvWriter.append(",");
csvWriter.append("Matches Played");
csvWriter.append("\n");
csvWriter.append(pname);
csvWriter.append(",");
csvWriter.append(tname);
csvWriter.append(",");
csvWriter.append(mplay);
csvWriter.append("\n");
csvWriter.flush();
csvWriter.close();	     
	
	}
}