import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Calendar;
public class CalendarClass {
    public static void main(String args[]) {
        
       Calendar calendar = Calendar.getInstance();
calendar.add(Calendar.DATE, 15);
System.out.println(calendar.get(Calendar.DATE));
    }
}