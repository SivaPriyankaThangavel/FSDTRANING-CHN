const products=[
    {
    name:'sandwich',freeDelivery:'Yes',price:'Rs.99.00',Category:'Main Course',
    pid:1
    },
    {
        name:'Burger',freeDelivery:'No',price:'Rs.129.00',Category:'Main Course',
        pid:2
        },
        {
            name:'Pizza',freeDelivery:'No',price:'Rs.149.00',Category:'Main Course',
            pid:3
            }
    
    ];
    
    
    const renderProducts=function(products)
    {
                    let tabE1=document.querySelector("#prod-tab");
                    
                    
                          products.forEach(function (product) {
                                    let trow1=document.createElement("tr");
                                    let tcol1=document.createElement("td");
                                    tcol1.textContent=product.name;
                                    trow1.appendChild(tcol1);
                                    
                                    let tcol2=document.createElement("td");
                                    tcol2.textContent=product.freeDelivery;
                                    trow1.appendChild(tcol2);
                    
                                    let tcol3=document.createElement("td");
                                    tcol3.textContent=product.price;
                                    trow1.appendChild(tcol3);
                                    
                                    
                                    let tcol4=document.createElement("td");
                                    tcol4.textContent=product.Category
                                    trow1.appendChild(tcol4);     

                                     let link=document.createElement("a");
                                    link.setAttribute('pid','link');
                                   
                                    link.href = "cart.html?id=" + product.pid +
                                    "&name=" + product.name + 
                                    "&freeDelivery="+product.freeDelivery +
                                    "&price=" + product.price +                                 
                                     "&Category="+product.Category ;                                  
                                     
                                    link.textContent="Add To Cart";
                                    let tcol5=document.createElement("td");
                                    tcol5.appendChild(link);
     
                                    trow1.appendChild(tcol5);
                                    
                                    tabE1.appendChild(trow1);
                                    
                    })
                    
                    
    }
    renderProducts(products);
     
  
     
     
    