package in.tp.swrdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebRestDemoBootCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebRestDemoBootCrudApplication.class, args);
	}

}
