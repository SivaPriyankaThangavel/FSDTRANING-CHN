package com.cts.jhd.ui;

import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cts.jhd.model.onetomany.Course;
import com.cts.jhd.model.onetomany.Trainee;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example7 {

	public static void main(String[] args) {
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		
		Trainee t1 = new Trainee(101, "Salman");
		Trainee t2 = new Trainee(102, "Amir");
		Trainee t3 = new Trainee(103, "Akshay");
		
		Set<Trainee> set = new TreeSet<Trainee>();
		set.add(t1); set.add(t2); set.add(t3);
		
		Course c1 = new Course(10, "Java FSD", set);
		
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(c1);
		txn.commit();
		
		JPAHibernateUtil.shutdown();

	}

}
