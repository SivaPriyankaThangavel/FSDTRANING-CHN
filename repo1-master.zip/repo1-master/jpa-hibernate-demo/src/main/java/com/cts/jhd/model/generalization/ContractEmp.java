package com.cts.jhd.model.generalization;

import javax.persistence.Entity;
import javax.persistence.Table;

//@Entity
//@DiscriminatorValue("C")


//@Entity
//@Table(name="cemps")

@Entity
@Table(name="cemps2")
public class ContractEmp extends Employee {
	private Integer contractDuration;
	
	public ContractEmp() {
		super();
	}
	
	public ContractEmp(Integer empId, String empName, Double salary, Integer contractDuration) {
		super(empId, empName, salary);
		this.contractDuration = contractDuration;
	}

	public Integer getContractDuration() {
		return contractDuration;
	}

	public void setContractDuration(Integer contractDuration) {
		this.contractDuration = contractDuration;
	}

	@Override
	public String toString() {
		return "ContractEmp [contractDuration=" + contractDuration + "]";
	}
	
}
