package com.cts.jhd.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cts.jhd.model.generalization.ContractEmp;
import com.cts.jhd.model.generalization.Employee;
import com.cts.jhd.model.generalization.Manager;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example5 {

	public static void main(String[] args) {
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		
		Employee e1 = new Employee(1, "srinivas", 10000.0);
		Manager m1 = new Manager(2, "divya", 12000.0, 5000.0);
		ContractEmp c1 = new ContractEmp(3, "savitha", 6000.0, 43);
		
		
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(e1);
		em.persist(m1);
		em.persist(c1);
		txn.commit();
		
		JPAHibernateUtil.shutdown();

	}

}
