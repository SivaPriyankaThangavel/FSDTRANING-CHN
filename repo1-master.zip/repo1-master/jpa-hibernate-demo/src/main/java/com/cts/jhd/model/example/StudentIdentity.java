package com.cts.jhd.model.example;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class StudentIdentity implements Serializable {

	private Integer rollNumber;
	private String section;
	private Integer clazz;
	
	public StudentIdentity() {
		super();
	}

	public StudentIdentity(Integer rollNumber, String section, Integer clazz) {
		super();
		this.rollNumber = rollNumber;
		this.section = section;
		this.clazz = clazz;
	}

	public Integer getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public Integer getClazz() {
		return clazz;
	}

	public void setClazz(Integer clazz) {
		this.clazz = clazz;
	}

	@Override
	public String toString() {
		return "StudentIdentity [rollNumber=" + rollNumber + ", section=" + section + ", clazz=" + clazz + "]";
	}
	
	
}
