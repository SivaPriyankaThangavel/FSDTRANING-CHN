package com.cts.jhd.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cts.jhd.model.example.Emp;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		Emp emp = new Emp();

		System.out.println("Enter empName : ");
		emp.setEmpName(scan.next());
		System.out.println("Enter basic : ");
		emp.setBasic(scan.nextDouble());
		
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		EntityTransaction txn= em.getTransaction();
		
		txn.begin();
		em.persist(emp);
		
		txn.commit();

		JPAHibernateUtil.shutdown();
		scan.close();
	}

}
