package com.cts.jhd.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cts.jhd.model.onetoone.BankAccount;
import com.cts.jhd.model.onetoone.Customer;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example6 {

	public static void main(String[] args) {
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		
		BankAccount b1 = new BankAccount("101201");
		Customer c1 = new Customer("A001", "Raghu", b1);
		
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(c1);
		txn.commit();
		
		JPAHibernateUtil.shutdown();

	}

}
