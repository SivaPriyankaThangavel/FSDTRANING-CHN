package com.cts.jhd.model.example;

import java.time.LocalDate;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="students")
public class Student {
	
	@EmbeddedId
	private StudentIdentity sid;
	
	private String firstName;
	private String lastName;
	
	@Transient
	private LocalDate dateOfBirth;
	
	
	public Student() {
		super();
	}


	public Student(StudentIdentity sid, String firstName, String lastName, LocalDate dateOfBirth) {
		super();
		this.sid = sid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
	}


	public StudentIdentity getSid() {
		return sid;
	}


	public void setSid(StudentIdentity sid) {
		this.sid = sid;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	@Override
	public String toString() {
		return "Student [sid=" + sid + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + "]";
	}
	
	
}
