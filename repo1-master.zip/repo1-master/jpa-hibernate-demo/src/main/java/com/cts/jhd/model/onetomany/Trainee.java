package com.cts.jhd.model.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainees")
public class Trainee implements Comparable<Trainee>{
	@Id
	private Integer admnNumber;
	private String sName;
	
	public Trainee() {
		super();
	}

	public Trainee(Integer admnNumber, String sName) {
		super();
		this.admnNumber = admnNumber;
		this.sName = sName;
	}

	public Integer getAdmnNumber() {
		return admnNumber;
	}

	public void setAdmnNumber(Integer admnNumber) {
		this.admnNumber = admnNumber;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	@Override
	public String toString() {
		return "Trainee [admnNumber=" + admnNumber + ", sName=" + sName + "]";
	}

	public int compareTo(Trainee other) {
	
		return (this.admnNumber < other.admnNumber ? -1 : (this.admnNumber > other.admnNumber ? 1 : 0));
	}
	
	
}
