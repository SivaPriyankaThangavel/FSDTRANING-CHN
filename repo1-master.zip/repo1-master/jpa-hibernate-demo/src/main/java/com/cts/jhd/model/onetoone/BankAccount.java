package com.cts.jhd.model.onetoone;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bankaccounts")
public class BankAccount {

	@Id
	private String acno;
	
	public BankAccount() {
		super();
	}

	public BankAccount(String acno) {
		super();
		this.acno = acno;
	}

	public String getAcno() {
		return acno;
	}

	public void setAcno(String acno) {
		this.acno = acno;
	}

	@Override
	public String toString() {
		return "BankAccount [acno=" + acno + "]";
	}
	
	
}
