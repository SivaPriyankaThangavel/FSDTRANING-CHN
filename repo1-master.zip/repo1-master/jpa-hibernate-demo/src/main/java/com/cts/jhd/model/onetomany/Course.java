package com.cts.jhd.model.onetomany;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="courses")
public class Course {
	@Id
	private Integer cId;
	private String cName;
	
	@OneToMany(cascade=CascadeType.PERSIST)
	private Set<Trainee> trainees;
	
	public Course() {
		super();
	}

	public Course(Integer cId, String cName, Set<Trainee> trainees) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.trainees = trainees;
	}

	public Integer getcId() {
		return cId;
	}

	public void setcId(Integer cId) {
		this.cId = cId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Set<Trainee> getTrainees() {
		return trainees;
	}

	public void setTrainees(Set<Trainee> trainees) {
		this.trainees = trainees;
	}

	@Override
	public String toString() {
		return "Course [cId=" + cId + ", cName=" + cName + ", trainees=" + trainees + "]";
	}
	
	
}
