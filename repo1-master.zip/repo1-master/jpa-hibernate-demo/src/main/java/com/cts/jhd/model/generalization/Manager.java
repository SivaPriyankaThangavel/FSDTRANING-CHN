package com.cts.jhd.model.generalization;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

//@Entity
//@DiscriminatorValue("M")

//@Entity
//@Table(name="mgrs")

@Entity
@Table(name="mgrs2")
public class Manager extends Employee {
	private Double allowance;
	
	public Manager() {
		super();
	}
	
	public Manager(Integer empId, String empName, Double salary, Double allowance) {
		super(empId, empName, salary);
		this.allowance = allowance;
	}

	public Double getAllowance() {
		return allowance;
	}

	public void setAllowance(Double allowance) {
		this.allowance = allowance;
	}

	@Override
	public String toString() {
		return "Manager [allowance=" + allowance + "]";
	}
}
