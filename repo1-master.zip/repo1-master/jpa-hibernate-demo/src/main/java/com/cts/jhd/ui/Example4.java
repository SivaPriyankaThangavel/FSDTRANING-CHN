package com.cts.jhd.ui;

import java.time.LocalDate;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.EntityTransaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.jhd.model.example.Emp;
import com.cts.jhd.model.example.Student;
import com.cts.jhd.model.example.StudentIdentity;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example4 {

	public static void main(String[] args) {
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		
		Student first = 
new Student(new StudentIdentity(1, "B", 5), "Srinivas", "Dachepalli", LocalDate.of(1966, 4, 9) );
		
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		em.persist(first);
		txn.commit();
		
		JPAHibernateUtil.shutdown();

	}

}
