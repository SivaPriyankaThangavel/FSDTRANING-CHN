package com.cts.jhd.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.EntityTransaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.jhd.model.example.Emp;
import com.cts.jhd.util.JPAHibernateUtil;

public class Example2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter empId : ");
		int empId = scan.nextInt();
		
		EntityManager em = JPAHibernateUtil.getEntityManagerFactory().createEntityManager();
		EntityTransaction txn= em.getTransaction();
		
		Emp emp = em.find(Emp.class, empId);
		if (emp==null) 
			System.out.println("Employee not found.");
		else {
			txn.begin();
			em.remove(emp);
			txn.commit();
			System.out.println("Employee deleted.");
		}
	
		JPAHibernateUtil.shutdown();
		scan.close();
	}

}
