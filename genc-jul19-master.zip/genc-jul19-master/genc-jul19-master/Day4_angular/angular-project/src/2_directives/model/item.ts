export class Item{
    constructor(public name:string, public id:number, public desc:string){}
}