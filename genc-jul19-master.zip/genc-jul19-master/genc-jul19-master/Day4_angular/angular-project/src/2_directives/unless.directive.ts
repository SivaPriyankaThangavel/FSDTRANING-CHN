import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
    selector: '[unless]'
})
export class UnlessDirective{
    constructor(private tempRef: TemplateRef<any>, private vcRef: ViewContainerRef){}

    @Input()
    set unless(condition:boolean){
        if(condition){
            console.log('hide');
            this.vcRef.clear();
        } else {
            console.log('show');
            this.vcRef.createEmbeddedView(this.tempRef);
        }
    }
}
