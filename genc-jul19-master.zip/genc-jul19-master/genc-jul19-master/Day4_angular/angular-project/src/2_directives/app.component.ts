import { Component } from '@angular/core';
import { Item } from './model/item';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isPresent: boolean = false;
  myClass: string = 'sub-heading';
  myStyle: any = {
    "text-align": "center",
    "border": "2px solid red"
  }

  items: Array<Item> = [
    new Item("Mobile", 123, "It is my fav mobile"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Laptop", 965, "It is my fav laptop"),
    new Item("Book", 521, "It is my fav book")
  ]

  constructor(){
    console.log(this.items)
  }

  toggleIsPresent(){
    this.isPresent = !this.isPresent;
  }
}
