import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: `home.component.html`,
    styleUrls: ['home.component.css']
})
export class HomeComponent{

    count:number = 10;
    constructor(){
        console.log('in home comp constructor')
    }

    inc(){
        this.count++;
    }
    dec(){
        this.count--;
    }
}