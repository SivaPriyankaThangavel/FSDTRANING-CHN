interface Post{
    userId:number;
    id:number;
    title:String;
    body:String;

}