export class User{
    constructor(
        public name:String,
        public email:string,
        public phone:number,
        public topic:string,
        public gender:string,
        public subscribe:boolean,
    ){}
}