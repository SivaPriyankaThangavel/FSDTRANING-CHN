import { EmplPipe } from './empl.pipe';

describe('EmplPipe', () => {
  it('create an instance', () => {
    const pipe = new EmplPipe();
    expect(pipe).toBeTruthy();
  });
});
