import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empl'
})
export class EmplPipe implements PipeTransform {

  transform(value: any, gender: string): any {
    if(gender=="Male"){
      return "Mr."+ value;
  }else{
      return "Mrs."+ value;
  }
}

}
