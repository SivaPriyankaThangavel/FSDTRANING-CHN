import { Component, OnInit } from '@angular/core';
import { userInfo } from 'os';
import { User } from '../models/user';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
  public UserModel=new User("priya","priy@gmail.com",9688945678,'HTML','male',true);
public topics=['HTML','CSS','ANGULAR'];
  constructor() { }

  ngOnInit() {
  }

}
